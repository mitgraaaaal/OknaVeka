$(function() {$(window).scroll(function() {if($(this).scrollTop() != 0) {$('#toTop').fadeIn();}else{$('#toTop').fadeOut();}});$('#toTop').click(function() {$('body,html').animate({scrollTop:0},800);});});




jQuery(document).ready(function() {
	
	$("img.lazy").lazyload();
	$('.sel-city').webuiPopover({url:'#sel-city-content'});
	$('.window-popover').webuiPopover({url:'#window-popover-content'});
	$('.search-popover').webuiPopover({url:'#search-popover-content'});
	$('.search-popover-mobile').webuiPopover({url:'#search-popover-content',placement:'bottom-left'});
	$('.uslugi-popover').webuiPopover({url:'#uslugi-popover-content'});
	$('.company-popover').webuiPopover({url:'#company-popover-content'});
	$('.balkon-popover').webuiPopover({url:'#balkon-popover-content'});	
	
	$('.promo_phone_class').val('+7');
	$('.promo_phone_class').keyup(function(e) {
		if((e.keyCode == 8) || (e.keyCode == 46)) {
			if($(this).val() == '') {
				$(this).val('+7');
			}
		}
	});
	//$('.promo_phone_class').formatter({
	//	'pattern': '+7({{999}}){{999}}-{{99}}-{{99}}',
	//	'persistent': true,
	//	'placeholder': '_'
	//});
	//$('[field=phone]').formatter({
	//	'pattern': '({{999}}){{999}}-{{99}}-{{99}}',
	//	'persistent': true,
	//	'placeholder': '_'
	//});
	
	
	$("[field=phone]").inputmask('+7(999)999-99-99');
	$(".promo_phone_class").inputmask('+7(999)999-99-99');
	
	$(function() {
		$('.audio-player-tag').mediaelementplayer({
			alwaysShowControls: true,
			features: ['playpause', 'progress', 'volume'],
			audioVolume: 'horizontal',
			width: 288,
			iPadUseNativeControls: false,
			iPhoneUseNativeControls: false,
			AndroidUseNativeControls: false
		});
	});
	$('.pseudo-link-popover').webuiPopover({
		'trigger': 'hover',
		'width': '240',
		'placement': 'auto',
		content: function() {
			return $('#' + $(this).attr('data-src')).html();
		}
	});
	
	$(document).on('click','.fancybox-video',function(){		
		$.fancybox({
				'padding'		: 0,
				'autoScale'		: false,
				'transitionIn'	: 'none',
				'transitionOut'	: 'none',
				'title'			: this.title,
				'fitToView' : true,
				'autoSize'  : true,
				'href'			: this.href,//.replace(new RegExp("watch\\?v=", "i"), 'v/'),
				'type'			: 'swf',
				'swf'			: {'wmode':'transparent','allowfullscreen':'true'}
			});

		return false;
	});	

	
});

var menu = document.querySelector('.top-fixed-row-menu');
document.onscroll = function() {
  if (window.pageYOffset > 100 && !menu.classList.contains('top-fixed-row-menu-visible')) {
    menu.classList.add('top-fixed-row-menu-visible');
	menu.classList.add('top-fixed-row-menu-size');
	$('.top-fixed-row-menu-container').toggle(800);
	$('.top-fixed-row-menu-timework').toggle(1000);
  }
  if (window.pageYOffset <= 100 && menu.classList.contains('top-fixed-row-menu-visible')) {
	$('.top-fixed-row-menu-timework').toggle(300);  
    $('.top-fixed-row-menu-container').toggle(800);
	menu.classList.remove('top-fixed-row-menu-size');
	menu.classList.remove('top-fixed-row-menu-visible');
  }
};


$(function() {
	var speed = 1500;
	
		setInterval(function() {
			
			var gift = document.querySelector('.blue-punkt-4');
			if (gift.classList.contains('gift4')) {
				gift.classList.remove('gift4');
				gift.classList.add('gift5');
			}else{
				gift.classList.remove('gift5');
				gift.classList.add('gift4');
			}			

		}, speed);		
});


$(document).ready(function() {
	$('.pseudo-link').click(function(e){
		e.preventDefault();
		var getval1 = ($(this).attr('href')).split('#');
		var getval2 = ($(this).attr('rel')).split('#');
		if((getval1[1]=='form8') || (getval2[1]=='form8') ){
			$(".fancy-zamer").click();
		}
		if((getval1[1]=='form7') || (getval2[1]=='form7') ){
			$(".fancy-recall").click();
		}
		return false;
	});		
	
	
     var API = $("#menu").data( "mmenu" );

	//avokado-call  
 

});